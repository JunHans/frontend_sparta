from flask import Flask, render_template, request, jsonify
app = Flask(__name__)

@app.route('/')
def home():
   return render_template('index.html')

@app.route('/test', methods=['GET'])
# /test라는 창구에서 아래에서 찍어준것을 받고있습니다
def test_get():
   title_receive = request.args.get('title_give')
# title_give라는 이름으로 뭔가를 받아왔고 그걸 변수에 넣었고
   print(title_receive)
# 그걸 찍어줬어 라는 뜻
   return jsonify({'result':'success', 'msg': '이 요청은 GET!'})


@app.route('/test', methods=['POST'])
# test라는 창구를 만들었고 post만 받는것은 이쪽으로 와라 GET은 위로가라
def test_post():
   title_receive = request.form['title_give']
   # 제일먼저, title_give는 가져왔니?>응 봄날은간다라고 써있었어/ 그러면 그거를 변수에다 저장해서 한번 프린트해봤어
   # 그러면 이제 난 일을 다했고, 너한테 다시어떤 데이터를 돌려줄거야 요청을잘받았어요(index.html에서 response에 들어간다)
   print(title_receive)
   return jsonify({'result':'success', 'msg': '요청을 잘 받았어요'})


if __name__ == '__main__':
   app.run('0.0.0.0',port=5000,debug=True)