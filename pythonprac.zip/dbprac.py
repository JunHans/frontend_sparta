from pymongo import MongoClient
client = MongoClient('mongodb+srv://test:sparta@cluster0.dpqflri.mongodb.net/Cluster0?retryWrites=true&w=majority')
                                # 아이디:비밀번호                               클러스터이름
db = client.dbsparta


# 저장 - 예시
doc = {'name':'bobby','age':21}
db.users.insert_one(doc)

# 한 개 찾기 - 예시
user = db.users.find_one({'name':'bobby'})

# 여러개 찾기 - 예시 ( _id 값은 제외하고 출력)
all_users = list(db.users.find({},{'_id':False}))

# 바꾸기 - 예시
db.users.update_one({'name':'bobby'},{'$set':{'age':19}})

# 지우기 - 예시
db.users.delete_one({'name':'bobby'})


# doc = {'name':'bobby','age':27}
# db.users.insert_one(doc)
# # 통상적으로 이렇게 많이 씀, 딕셔너리 하나 만들어 주고 걔를 넣어라 이런식으로

# db.users.insert_one({'name':'john','age':20})
# db.users.insert_one({'name':'ann','age':20})
#  # 콜렉션이름

# <전부 나오게>
# all_users = list(db.users.find({},{'_id':False}))
#                                 # _id는 자동으로 나오는 거기 떄문에 그거 빼고 나오라고
#
# for user in all_users:
#     print(user)

# <하나 나오게>
# user = db.users.find_one({'name':'bobby'})
# print(user['age'])

# <업데이트>
# db.users.update_one({'name':'bobby'},{'$set':{'age':19}})
# users라는 곳에 가서 하나를 업데이트하는데 bobby라는 애의 age를 19로 업데이트해라 : 해석