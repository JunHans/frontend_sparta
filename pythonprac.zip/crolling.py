import requests
from bs4 import BeautifulSoup

from pymongo import MongoClient
client = MongoClient('mongodb+srv://test:sparta@cluster0.dpqflri.mongodb.net/Cluster0?retryWrites=true&w=majority')
db = client.dbsparta

headers = {'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36'}
data = requests.get('https://movie.naver.com/movie/sdb/rank/rmovie.naver?sel=pnt&date=20210829',headers=headers)

soup = BeautifulSoup(data.text, 'html.parser')
# 이게 기본셋팅이고 아무도 못외운다, 강사님도 필요할때마다 자기가 써놨던 크롤링 코드 보고 복사해온다, url만 바꿔서 쓴다

# 코딩 시작
#old_content > table > tbody > tr:nth-child(3) > td.title > div > a
#old_content > table > tbody > tr:nth-child(4) > td.title > div > a

movies = soup.select('#old_content > table > tbody > tr')

for movie in movies:
    a = movie.select_one('td.title > div > a')
    if a is not None:
        title = a.text

        rank = movie.select_one('td:nth-child(1) > img')['alt']
        # tr까지는 내가 위에서 이미 가져왔다. 그만큼 지워주고 print(rank)사용해서 rank가 어떻게 생겼는지 한번 본다.
        # 보니 alt값만 있으면 되네? 뒤에 ['alt']붙여준다

        star = movie.select_one('td.point').text
        # tr까지는 내가 위에서 이미 가져왔다. 그만큼 지워주고 print(star)사용해서 star가 어떻게 생겼는지 한번 본다.
        # 확인해 보니 text값만 가져오면 되겠다. 뒤에 .text붙여준다.

        doc = {
            'title':title,
            'rank':rank,
            'star':star
        }
        db.movies.insert_one(doc)

        print(rank)