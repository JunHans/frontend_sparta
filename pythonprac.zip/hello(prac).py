# 크롤링을 하려면 패키지를 설치해야 한다. 패키지 설치 = 외부 라이브러리 설치

# people = [{'name': 'bob', 'age': 20},
#           {'name': 'carry', 'age': 38},
#           {'name': 'john', 'age': 7},
#           {'name': 'smith', 'age': 17},
#           {'name': 'ben', 'age': 27}]
#
# for person in people:
# # 보통 단수 복수 이렇게 간다, person은 그냥 ppp , aaa뭘로 쓰든 상과없다
# # 그저 하나씩 꺼내서 쓰겠다는 뜻입니다.
#
#     if person['age'] > 20:
#         print(person['name'])


# # <반복문>
# fruits = ['사과','배','배','감','수박','귤','딸기','사과','배','수박']
#
# count = 0
# for aaa in fruits:
#     if aaa == '사과':
#         count += 1
#
#
# print(count)


# # <조건문>
# def is_adult(age):
#     if age > 20:
#         print('성인입니다')
#     else:
#         print('청소년입니다')
# # :는 다음 TAb을 한번 한게 나의 내용물입니다 라는 뜻
# #     그래서 들여쓰기가 파이썬에선 굉장히 중요함
# is_adult(15)



# <함수>
# def sum(a,b):
#     print('더하자!')
#     return a+b
# # return은 나를 변신시켜라 라는 뜻 (a,b)에 (1,2)를 넣고 a+b로 변신시키는 것
# # 순서상 '더하자'가 나오고 값이 출력 된다
#
# result = sum(1,2)
# print(result)