from pymongo import MongoClient
client = MongoClient('mongodb+srv://test:sparta@cluster0.dpqflri.mongodb.net/Cluster0?retryWrites=true&w=majority')
db = client.dbsparta


# movie =db.movies.find_one({'title':'가버나움'})
# <가버나움과 평점이 같은애들 다 띄우기>
# star = movie['star']
# # 스타라는 값에다가 movie의 star를 넣고,
#
# all_movies = list(db.movies.find({'star':star},{'_id':False}))
#                                 # 조건: star가 위에 써놧던 star
# for m in all_movies:
#     print(m['title'])
#     # 편의상 그냥 m이라고 한 거고 제목만 가져오기 위해 title쓴 것

# <가버나움의 평점 0으로 바꾸기>
db.movies.update_one({'title':'가버나움'},{'$set':{'star':'0'}})